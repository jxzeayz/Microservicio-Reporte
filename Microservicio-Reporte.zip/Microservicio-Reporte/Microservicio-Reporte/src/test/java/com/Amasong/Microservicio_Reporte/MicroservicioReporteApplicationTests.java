package com.Amasong.Microservicio_Reporte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootTest
@SpringBootApplication
public class MicroservicioReporteApplicationTests {
    public static void main(String[] args) {
        SpringApplication.run(MicroservicioReporteApplicationTests.class, args);
    }
}