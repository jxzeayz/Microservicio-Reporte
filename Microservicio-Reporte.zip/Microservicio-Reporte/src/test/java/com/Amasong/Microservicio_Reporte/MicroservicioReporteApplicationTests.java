package com.Amasong.Microservicio_Reporte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioReporteApplicationTests {

	@Test
	void contextLoads() {
	}

}
